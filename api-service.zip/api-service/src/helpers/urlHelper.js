const baseUrl = (path) => {
  return 'https://api-service-7b6z6isa7a-et.a.run.app' + '/' + path;
};

module.exports = {
  baseUrl
};